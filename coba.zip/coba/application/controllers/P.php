<?php
defined('BASEPATH') or exit('No direct script access allowed');

class P extends CI_Controller
{
    public function index()
    {
        $this->load->view('templates/header');
        $this->load->view('admin/index');
        $this->load->view('templates/footer');
    }

    public function create_list()
    {
    }
}
